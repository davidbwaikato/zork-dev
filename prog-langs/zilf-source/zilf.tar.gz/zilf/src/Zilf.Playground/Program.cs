/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using Zilf.Playground.Services.Builds;
using Zilf.Playground.Services.Workspaces;
using Zilf.Playground.Services.Repl;
using Zilf.Playground.Services.Templates;
using Zilf.Playground.Services;
using BlazorWorker.Core;

namespace Zilf.Playground
{
    public class Program
    {
        public static Task Main(string[] args)
        {
            var builder = WebAssemblyHostBuilder.CreateDefault(args);
            builder.Logging.SetMinimumLevel(LogLevel.Debug);

            builder.RootComponents.Add<App>("#app");

            builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });

            builder.Services.AddSingleton<JSInterop>();
            builder.Services.AddSingleton<StoryPlayerService>();
                builder.Services.AddSingleton<VersionService>();
            builder.Services.AddSingleton<ProjectStorageService>();
            builder.Services.AddScoped<TemplateService>();
            builder.Services.AddScoped(sp =>
                new WorkspaceService(sp.GetRequiredService<ProjectStorageService>()));
            builder.Services.AddScoped<ReplService>();
            builder.Services.AddScoped<BuildService>();
            builder.Services.AddScoped(sp =>
                new ReleaseService(
                    sp.GetRequiredService<IJSRuntime>(),
                    sp.GetRequiredService<HttpClient>()));

            builder.Services.AddWorkerFactory();

            return builder.Build().RunAsync();
        }
    }
}
