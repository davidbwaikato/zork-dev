/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using System;

namespace Zilf.Interpreter
{
    /// <summary>
    /// Specifies that a constructor or static method implements CHTYPE for a builtin type.
    /// </summary>
    /// <remarks>
    /// <para>If applied to a constructor, it must take a single value of the primitive type.</para>
    /// <para>If applied to a static method, it must take either one or two parameters,
    /// an optional <see cref="Context"/> followed by the primitive type, and return a type
    /// assignable to <see cref="Values.ZilObject"/>.</para>
    /// </remarks>
    /// <seealso cref="BuiltinTypeAttribute"/>
    [AttributeUsage(AttributeTargets.Constructor | AttributeTargets.Method)]
    sealed class ChtypeMethodAttribute : Attribute
    {
    }
}