﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using Zapf.Parsing.Expressions;

namespace Zapf.Parsing.Directives
{
    public sealed class DebugObjectDirective(AsmExpr number, string name,
         AsmExpr startFile, AsmExpr startLine, AsmExpr startColumn,
         AsmExpr endFile, AsmExpr endLine, AsmExpr endColumn) : DebugDirective
    {
        public AsmExpr Number { get; } = number;
        public string Name { get; } = name;
        public AsmExpr StartFile { get; } = startFile;
        public AsmExpr StartLine { get; } = startLine;
        public AsmExpr StartColumn { get; } = startColumn;
        public AsmExpr EndFile { get; } = endFile;
        public AsmExpr EndLine { get; } = endLine;
        public AsmExpr EndColumn { get; } = endColumn;
    }
}