﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using System;
using System.Collections.Generic;
using System.Linq;

namespace Zilf.Common.StringEncoding.SuffixTrees
{
    /// <summary>
    /// Implements a Generalized Suffix Tree using Ukkonen's algorithm.
    /// </summary>
    /// <typeparam name="T">The type of data to associate with each string added to the tree.</typeparam>
    /// <remarks>
    /// A suffix tree is a compressed trie containing all the suffixes of the input strings.
    /// This implementation supports multiple strings (generalized suffix tree) and allows
    /// searching for substrings, counting occurrences, and retrieving associated data.
    /// See also:
    /// <list type="bullet">
    /// <item>https://github.com/gmamaladze/trienet</item>
    /// <item>https://github.com/abahgat/suffixtree</item>
    /// <item>https://www.abahgat.com/project/suffix-tree/</item>
    /// <item>http://programmerspatch.blogspot.com/2013/02/ukkonens-suffix-tree-algorithm.html</item>
    /// <item>https://www.geeksforgeeks.org/suffix-tree-application-2-searching-all-patterns/</item>
    /// </list>
    /// </remarks>
    public sealed class SuffixTree<T>
    {
        private readonly Node<T> root;
        private Node<T> activeLeaf;
        private bool annotated;

        /// <summary>
        /// Initializes a new instance of the <see cref="SuffixTree{T}"/> class.
        /// </summary>
        public SuffixTree()
        {
            activeLeaf = root = new Node<T>();
        }

        /// <summary>
        /// Searches for all distinct data values associated with strings containing the specified substring.
        /// </summary>
        /// <param name="word">The substring to search for.</param>
        /// <returns>A sequence of distinct data values associated with strings containing the substring,
        /// or an empty sequence if the substring is not found.</returns>
        public IEnumerable<T> Search(string word)
        {
            var tmpNode = SearchNodeInternal(word);
            if (tmpNode == null)
                return Enumerable.Empty<T>();
            return tmpNode.GetData().Distinct();
        }

        /// <summary>
        /// Searches for all data values associated with strings containing the specified substring,
        /// along with the depth (position) where each occurrence ends.
        /// </summary>
        /// <param name="word">The substring to search for.</param>
        /// <returns>A sequence of tuples containing data values and their corresponding depths,
        /// or an empty sequence if the substring is not found.</returns>
        /// <remarks>
        /// The depth represents the number of characters from the start of the original string
        /// to the end of the matched substring. This method triggers annotation if not already done.
        /// </remarks>
        public IEnumerable<(T data, int depth)> SearchWithDepth(string word)
        {
            Annotate();

            var tmpNode = SearchNodeInternal(word);
            if (tmpNode == null)
                return Enumerable.Empty<(T, int)>();
            return tmpNode.GetDataWithDepth().Distinct();
        }

        /// <summary>
        /// Counts the total number of occurrences of the specified substring across all strings in the tree.
        /// </summary>
        /// <param name="word">The substring to count.</param>
        /// <returns>The number of occurrences, or zero if the substring is not found.</returns>
        /// <remarks>
        /// This method triggers annotation if not already done.
        /// </remarks>
        public int CountOccurrences(string word)
        {
            Annotate();

            var tmpNode = SearchNodeInternal(word);
            if (tmpNode == null)
                return 0;
            return tmpNode.ResultCount;
        }

        /// <summary>
        /// Ensures the tree has been annotated with computed metrics.
        /// </summary>
        /// <remarks>
        /// Annotation is required for operations that need depth, leaf count, or result count information.
        /// This method is idempotent and will only perform annotation once.
        /// </remarks>
        private void Annotate()
        {
            if (!annotated)
            {
                root.Annotate();
                annotated = true;
            }
        }

        /// <summary>
        /// Gets the root node of the suffix tree.
        /// </summary>
        /// <returns>A read-only view of the root node.</returns>
        /// <remarks>
        /// This method triggers annotation before returning the root, ensuring all metrics are available.
        /// </remarks>
        public INode<T> GetRoot()
        {
            Annotate();
            return root;
        }

        /// <summary>
        /// Searches for the node corresponding to a given substring.
        /// </summary>
        /// <param name="word">The substring to search for.</param>
        /// <returns>A read-only view of the node representing the end of the substring path,
        /// or <c>null</c> if not found.</returns>
        /// <remarks>
        /// This method triggers annotation before searching, ensuring all metrics are available
        /// on the returned node.
        /// </remarks>
        public INode<T>? SearchNode(string word)
        {
            Annotate();
            return SearchNodeInternal(word);
        }

        /// <summary>
        /// Searches for the node corresponding to a given substring.
        /// </summary>
        /// <param name="word">The substring to search for.</param>
        /// <returns>The node representing the end of the substring path, or <c>null</c> if not found.</returns>
        /// <remarks>
        /// This method traverses the tree following edges that match the characters in the word.
        /// It handles both exact edge label matches and partial matches within edge labels.
        /// </remarks>
        private Node<T>? SearchNodeInternal(ReadOnlySpan<char> word)
        {
            var currentNode = root;

            for (int i = 0; i < word.Length; i++)
            {
                if (!currentNode.Edges.TryGetValue(word[i], out var currentEdge))
                    return null;

                var label = currentEdge.Label;
                int lenToMatch = Math.Min(word.Length - i, label.Length);

                if (!word.Slice(i, lenToMatch).Equals(label.Span[..lenToMatch], StringComparison.Ordinal))
                    return null;

                if (label.Length >= word.Length - i)
                    return currentEdge.Dest;

                currentNode = currentEdge.Dest;
                i += lenToMatch - 1;
            }

            return null;
        }

        /// <summary>
        /// Adds a string to the suffix tree with associated data.
        /// </summary>
        /// <param name="key">The string to add.</param>
        /// <param name="value">The data to associate with the string.</param>
        /// <remarks>
        /// This method uses Ukkonen's algorithm to efficiently add all suffixes of the string to the tree.
        /// After adding a string, the tree must be re-annotated before operations that depend on metrics.
        /// The algorithm runs in O(n) time where n is the length of the string.
        /// </remarks>
        public void Add(string key, T value)
        {
            annotated = false;

            activeLeaf = root;

            var keyMemory = key.AsMemory();
            var s = root;

            int start = 0, end = 0;
            for (int i = 0; i < keyMemory.Length; i++)
            {
                end++;

                var (updateLastNode, updateTrimmed) = Update(s, keyMemory[start..end], keyMemory[i..], value);
                var (canonizeS, canonizeTrimmed) = Canonize(updateLastNode, keyMemory[(start + updateTrimmed)..end]);
                s = canonizeS;
                start += updateTrimmed + canonizeTrimmed;
            }

            if (activeLeaf.Suffix == null && activeLeaf != root && activeLeaf != s)
                activeLeaf.Suffix = s;
        }

        /// <summary>
        /// Tests whether a node already contains a path for the given character, and splits an edge if necessary.
        /// </summary>
        /// <param name="inputs">The starting node for the test.</param>
        /// <param name="stringPart">The substring representing the path from the root to the current position.</param>
        /// <param name="t">The character to test for.</param>
        /// <param name="remainder">The remaining portion of the string being added.</param>
        /// <param name="value">The data value being associated with the string.</param>
        /// <returns>A tuple indicating whether the path is already contained (true) or a new branch was created (false),
        /// and the node where the operation occurred or a newly created split node.</returns>
        /// <remarks>
        /// This is a core operation in Ukkonen's algorithm. If an edge needs to be split (the character appears
        /// in the middle of an edge label), this method creates a new internal node and adjusts the edges accordingly.
        /// </remarks>
        private static (bool contained, Node<T> lastNode) TestAndSplit(Node<T> inputs, ReadOnlyMemory<char> stringPart,
            char t, ReadOnlyMemory<char> remainder, T value)
        {
            var (s, trimmed) = Canonize(inputs, stringPart);
            var str = stringPart[trimmed..];

            if (str.Length != 0)
            {
                var g = s.Edges[str.Span[0]];
                var label = g.Label;
                if (label.Length > str.Length && label.Span[str.Length] == t)
                    return (true, s);

                var newLabel = label[str.Length..];

                var r = new Node<T>();
                var newEdge = new Edge<T>(str, r);

                g.Label = newLabel;

                r.Edges.Add(newLabel.Span[0], g);
                s.Edges[str.Span[0]] = newEdge;

                return (false, r);
            }

            if (!s.Edges.TryGetValue(t, out var e))
                return (false, s);

            if (remainder.Span.Equals(e.Label.Span, StringComparison.Ordinal))
            {
                e.Dest.AddRef(value);
                return (true, s);
            }

            if (remainder.Span.StartsWith(e.Label.Span))
                return (true, s);

            if (e.Label.Span.StartsWith(remainder.Span))
            {
                var newNode = new Node<T>();
                newNode.AddRef(value);

                var newEdge = new Edge<T>(remainder, newNode);

                e.Label = e.Label[remainder.Length..];

                newNode.Edges.Add(e.Label.Span[0], e);

                s.Edges[t] = newEdge;

                return (false, s);
            }

            return (true, s);
        }

        /// <summary>
        /// Canonizes a reference pair (node, string) to find the canonical reference for the same location.
        /// </summary>
        /// <param name="s">The starting node.</param>
        /// <param name="inputStr">The substring from the node.</param>
        /// <returns>A tuple containing the canonical node and the number of characters trimmed from the input.</returns>
        /// <remarks>
        /// Canonization is a key concept in Ukkonen's algorithm. It ensures that a (node, substring) pair
        /// is represented in a canonical form by following explicit edges as far as possible. This operation
        /// runs in O(1) amortized time due to the suffix link structure.
        /// </remarks>
        private static (Node<T> lastNode, int leftTrimmedChars) Canonize(Node<T> s, ReadOnlyMemory<char> inputStr)
        {
            var trimmed = 0;

            if (inputStr.Length == 0)
                return (s, trimmed);

            var currentNode = s;
            var str = inputStr;
            var g = s.Edges[str.Span[0]];

            while (g != null && str.Span.StartsWith(g.Label.Span))
            {
                str = str[g.Label.Length..];
                trimmed += g.Label.Length;
                currentNode = g.Dest;
                if (str.Length > 0)
                    g = currentNode.Edges[str.Span[0]];
            }

            return (currentNode, trimmed);
        }

        /// <summary>
        /// Updates the suffix tree by adding a new character and all its suffixes.
        /// </summary>
        /// <param name="inputNode">The active node at the start of the update.</param>
        /// <param name="stringPart">The active substring being processed.</param>
        /// <param name="rest">The remaining portion of the string to be added.</param>
        /// <param name="value">The data value associated with the string.</param>
        /// <returns>A tuple containing the final active node and the number of characters consumed.</returns>
        /// <remarks>
        /// This is the main update procedure in Ukkonen's algorithm. It adds all necessary suffixes for the
        /// new character by following suffix links and creating new edges/nodes as needed. The algorithm maintains
        /// suffix links to enable efficient suffix traversal.
        /// </remarks>
        private (Node<T> lastNode, int trimmed) Update(Node<T> inputNode, ReadOnlyMemory<char> stringPart, ReadOnlyMemory<char> rest, T value)
        {
            var trimmed = 0;

            var s = inputNode;
            var tempStr = stringPart;
            var newChar = stringPart.Span[^1];

            var oldRoot = root;

            var (endpoint, r) = TestAndSplit(s, tempStr[..^1], newChar, rest, value);

            Node<T> leaf;
            while (!endpoint)
            {
                if (r.Edges.TryGetValue(newChar, out var tempEdge))
                {
                    leaf = tempEdge.Dest;
                }
                else
                {
                    leaf = new Node<T>();
                    leaf.AddRef(value);
                    var newEdge = new Edge<T>(rest, leaf);
                    r.Edges.Add(newChar, newEdge);
                }

                if (activeLeaf != root)
                    activeLeaf.Suffix = leaf;

                activeLeaf = leaf;

                if (oldRoot != root)
                    oldRoot.Suffix = r;

                oldRoot = r;

                if (s.Suffix == null)
                {
                    tempStr = tempStr[1..];
                    trimmed++;
                }
                else
                {
                    var (canonizeLastNode, canonizeTrimmed) = Canonize(s.Suffix, SafeCutLastChar(tempStr));
                    s = canonizeLastNode;
                    tempStr = tempStr[canonizeTrimmed..];
                    trimmed += canonizeTrimmed;
                }

                (endpoint, r) = TestAndSplit(s, SafeCutLastChar(tempStr), newChar, rest, value);
            }

            if (oldRoot != root)
                oldRoot.Suffix = r;

            return (s, trimmed);
        }

        /// <summary>
        /// Safely removes the last character from a substring, returning an empty substring if already empty.
        /// </summary>
        /// <param name="seq">The substring to trim.</param>
        /// <returns>The substring with the last character removed, or an empty substring if the input was empty.</returns>
        private static ReadOnlyMemory<char> SafeCutLastChar(ReadOnlyMemory<char> seq)
        {
            if (seq.Length == 0)
                return seq;

            return seq[..^1];
        }
    }

    /// <summary>
    /// Provides extension methods for working with spans.
    /// </summary>
    public static class SpanExtensions
    {
        /// <summary>
        /// Computes the sum of values in a span after applying a selector function to each element.
        /// </summary>
        /// <typeparam name="T">The type of elements in the span.</typeparam>
        /// <param name="span">The span to sum.</param>
        /// <param name="selector">A function to transform each element into an integer value.</param>
        /// <returns>The sum of all transformed values.</returns>
        public static int Sum<T>(this ReadOnlySpan<T> span, Func<T, int> selector)
        {
            int result = 0;

            foreach (var i in span)
                result += selector(i);
            return result;
        }
    }
}
